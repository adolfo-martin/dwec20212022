import { from, Observable, of, zip } from 'rxjs'
import { map, take, mergeMap, concatMap, catchError, retry, pluck } from 'rxjs/operators'
import { ajax } from 'rxjs/ajax'
import XMLHttpRequest from 'xhr2'

retrieveCountries$().subscribe(console.log)

// retrieveBordersNames$([ 'IRN', 'PAK', 'TKM', 'UZB', 'TJK', 'CHN' ])
//     .subscribe(console.log)

function retrieveBordersNames$(countries) {
    //return zip(...countries.map(code => retrieveCountryByCode$(code).pipe(pluck('name'))))
    return from(countries).pipe(
        concatMap( code => retrieveCountryByCode$(code)),
        pluck('name'),
        unflat,
    )
    // zip(...countries.map(code => retrieveCountryByCode$(code).pipe(pluck('name'))))
}

function unflat(elements$) {
    return new Observable(subscriber => {
        const result = []
        elements$.subscribe({
            next: element => result.push(element),
            complete: () => {
                subscriber.next(result)
                subscriber.complete()
            },
            error: console.error,
        })
    })
}

function retrieveCountryByCode$(code) {
    const url = `http://127.0.0.1/api/countries/${code}`

    return ajax({
        url,
        createXHR: () => new XMLHttpRequest()
    }).pipe(
        parseJson(),
        extractCountry(),
        retry(10)
    )
}

function extractCountry() {
    return map(({country}) => country)
}

function extractCodeNameAndBorders() {
    return map(({alpha3Code: code, name, borders}) => ({
        code, 
        name, 
        borders: borders ? borders : []
    }))
}

function parseJson() {
    return map(({response : data}) => data)
}

function extractCountries() {
    return map(({countries}) => countries)
}

function flatCountries() {
    return mergeMap(countries => countries)
}

function retrieveCountries$() {
    const url = 'http://127.0.0.1/api/countries'

    return ajax({
        url,
        createXHR: () => new XMLHttpRequest()
    }).pipe(
        parseJson(),
        extractCountries(),
        flatCountries(),
        take(15),
        concatMap(country => retrieveCountryByCode$(country.code)),
        extractCodeNameAndBorders(),
        concatMap(({code, name, borders}) => retrieveBordersNames$(borders)
            .pipe(
                concatMap(borders => of({code, name, borders}))
            )
        ),
        catchError(error => of('Hay un error')),
    )
}